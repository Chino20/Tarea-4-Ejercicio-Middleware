Create Database Motos;
use Motos;

Create table Motos
(
Due�o varchar(3) primary key,
Marca varchar(20) not null,
Modelo varchar(20) not null,
A�o int not null,
)

select * from Motos;

insert into Motos values('Edu','Italika','Ft150',2018)