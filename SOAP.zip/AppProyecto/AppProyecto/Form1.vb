﻿Public Class Form1

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        CargarDatos()

    End Sub

    Private Sub Label1_Click(sender As System.Object, e As System.EventArgs) Handles Label1.Click

    End Sub

    Private Sub Label2_Click(sender As System.Object, e As System.EventArgs) Handles Label2.Click

    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Dim ObjWebMotos As New WebMotos.Service
        Dim Respuestas As String
        Respuestas = ObjWebMotos.FnAgregarMotos(Me.TextBox1.Text, Me.TextBox2.Text, Me.TextBox3.Text, Me.TextBox4.Text)
        MessageBox.Show(Respuestas)
        CargarDatos()
        Me.TextBox1.Clear()
        Me.TextBox2.Clear()
        Me.TextBox3.Clear()
        Me.TextBox4.Clear()
    End Sub


    Private Sub CargarDatos()
        Dim ObjWebMotos As New WebMotos.Service
        Dim DsX As New DataSet

        DsX = ObjWebMotos.FmMostrarRegistros
        Me.DGVMotos.DataSource = DsX.Tables("Motos")
    End Sub


    Private Sub TextBox4_TextChanged(sender As System.Object, e As System.EventArgs) Handles TextBox4.TextChanged

    End Sub

    Private Sub DGVMotos_CellContentClick(sender As System.Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DGVMotos.CellContentClick

    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Dim ObjWebMotos As New WebMotos.Service
        Dim Respuestas As String
        Respuestas = ObjWebMotos.FnEliminarMotos(Me.TextBox1.Text)
        MessageBox.Show(Respuestas)
        CargarDatos()
        Me.TextBox1.Clear()
    End Sub
End Class

